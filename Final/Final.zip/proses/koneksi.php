<?php
        $conn = mysqli_connect("localhost","root","","growtani")
        or die ("koneksi gagal");
?>