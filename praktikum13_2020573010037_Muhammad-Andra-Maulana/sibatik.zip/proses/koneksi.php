<?php
        $conn = mysqli_connect("localhost","root","","sibatik")
        or die ("koneksi gagal");
?>